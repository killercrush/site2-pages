document.addEventListener("DOMContentLoaded", init);
window.onload = function() {
    resizeMap();
};
window.addEventListener("resize", resizeMap);
function init() {
    $(".hamburger").colorbox({ inline: true, width: "100%" });
    $(".carousel-item__thumb-overlay").colorbox({ width: "100%" });
    $(".carousel").owlCarousel({
        nav: true,
        dots: true,
        margin: 20,
        //center: true,
        navText: ["",""],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:3
            },
            1200:{
                items:4
            }
        }
    });
    $(".projects").owlCarousel({
        nav: true,
        dots: true,
        margin: 20,
        navText: ["",""],        
        responsive: {
            0:{
                items:1
            },
            768:{
                items:3
            },
            1200:{
                items:4
            }
        }
    });
    $(".testimonials").owlCarousel({
        nav: true,
        loop: true,
        navText: ["",""],        
        items: 1
    });        
}
function resizeMap() {
   var map = document.getElementById("map");
   var height = document.getElementsByClassName("testimonials")[0].getBoundingClientRect().height;
   map.style.height = height + "px";
}